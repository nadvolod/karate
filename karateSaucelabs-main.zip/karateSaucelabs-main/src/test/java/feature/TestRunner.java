/*
 * Copyright (c) Gek Yeo
 */

package feature;

import com.intuit.karate.junit5.Karate;

class testRunner
{
	@Karate.Test
	Karate testSaucelabExample() {
		return Karate.run("test").relativeTo(getClass());
	}
}
