function fn() {
	var driverDimensions = {
		x: 0,
		y: 0,
		width: 1440,
		height: 1920
	}
	var browser = {
		driver: {
			type: karate.properties['driver.type'] || 'chromedriver'
		}
	}

	switch(browser.driver.type) {
		case 'chromedriver':
			sauceBrowser = 'chrome';
			break;
		case 'safaridriver':
			sauceBrowser = 'safari';
			break;
		case 'geckodriver':
			sauceBrowser = 'firefox';
			break;
	}

	switch(browser.driver.type) {
		case 'chromedriver':
			sauceBrowser = 'chrome';
			break;
		case 'safaridriver':
			sauceBrowser = 'safari';
			break;
		case 'geckodriver':
			sauceBrowser = 'firefox';
			break;
	}

	var envData = {
		local: {
			driver: {
				type: browser.driver.type,
			},
			config: {
				driverDimensions: driverDimensions,
				webapp: {
					url: 'https://saucelabs.com'
				}
			}
		},
		saucelabs: {
			driver: {
				type: browser.driver.type,
				start: false,
				httpConfig: {
					readTimeout: 90000,
					connectTimeout: 90000
				},
				webDriverSession: {
					capabilities: {
						alwaysMatch: {
							browserName: sauceBrowser,
							platformName: 'macOS 10.15',
							'sauce:options': {
								screenResolution: '1920x1440',
								maxDuration: '10800',
								idleTimeout:'1000'
							},
						}
					}
				},
				webDriverUrl: karate.properties['saucelabs.driver.url'] || java.lang.System.getenv('SAUCE_DRIVER_CREATION_URL')
			},
			config: {
				driverDimensions: driverDimensions,
				webapp: {
					url: 'https://saucelabs.com'
				},
				sauce:{
					url: 'https://api.eu-central-1.saucelabs.com/rest/v1/',
					username: java.lang.System.getenv('SAUCE_USERNAME'),
					pw: java.lang.System.getenv('SAUCE_ACCESS_KEY'),
					build: java.lang.System.getenv('BUILD_NUMBER') || 'build-001'
				}
			}
		}
	};

	var dataForCurrentEnvironment = envData[karate.env || 'local'];

	if (!dataForCurrentEnvironment) {
		karate.log('Aborting test suite run. No environment configuration found for environment: ', karate.env);
		karate.abort();
	}

	karate.configure('driver', dataForCurrentEnvironment.driver);

	return dataForCurrentEnvironment.config;
}
