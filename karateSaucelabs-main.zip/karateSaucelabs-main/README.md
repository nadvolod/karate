# karateSaucelabs
# Karate example with Saucelabs  
 [Karate framework](https://github.com/intuit/karate) for a test with saucelabs

Karate is a Cucumber syntax driven testing framework that started off as an API testing framework that allows for APIs to be tested with "no code". It has recently added UI testing support as part of [karate-core](https://intuit.github.io/karate/karate-core). Due to its API testing roots and the way the UI support has been added, it means UI and API actions can be combined in the same Cucumber features to create complex UI and API tests with relative ease.

## Running the tests
### Prerequisites
Java 11

### Environment variables

* Set the `WEB_URL` environment variable for the url you want to run against if you don't want to use the default webapp url.
* Set your `SAUCE_USERNAME` and `SAUCE_ACCESS_KEY`
* Set `SAUCE_DRIVER_CREATION_URL`. Get this value from the same page as your `SAUCE_USERNAME` and `SAUCE_ACCESS_KEY`. Below is an example of what I did. 
* 

```bash
export SAUCE_DRIVER_CREATION_URL=https://nikolay-a:3c9c7da6-9264-4b46-8aae-8f3806a1e645@ondemand.us-west-1.saucelabs.com:443/wd/hub
```

### Running with gradle
Once all prerequisites have been met you can run the test suite with `./gradlew test`

./gradlew build test -Ddriver.type=chromedriver -Dkarate.env=saucelabs

##### Changing the browser
By default the suite will run with the `chromedriver` driver type. If you wish to run against a different browser you can provide one of the [supported driver types](https://intuit.github.io/karate/karate-core/#driver-types) via the `driver.type` JVM option e.g. `./gradlew test -Ddriver.type=safaridriver`.

NOTE: You will need to have the executable for whichever driver you wish to run against installed and on your path (see the [Prerequisites section](#Prerequisites) for details on each driver/browser).

### Debugging the tests
Karate has its own [Visual Studio Code Extension](https://marketplace.visualstudio.com/items?itemName=kirkslota.karate-runner) that allows for debugging of scenarios, allowing you to set breakpoints, step through commands and even step back.

Once you have the extension installed read the "Setup -> Debugger" section of the extensions instructions for how to configure the Visual Studio Code debugger to work with this gradle project. NOTE: Once you have created the gradle configuration in the `launch.json` files you do not need the "standalone" configuration so you can remove it.

### Running with SauceLabs
To run the test suite against sauce labs you will need to:
1. Login to SauceLabs
1. Retrieve your username, access key and driver creation URL from "Account" -> "User Settings"
1. Setup `SAUCE_USERNAME`, `SAUCE_ACCESS_KEY` and `SAUCE_DRIVER_CREATION_URL` environment variables with the values from the previous step
1. Run the test suite against the `saucelabs` environment with `./gradlew test -Dkarate.env=saucelabs`. This will use default chromedriver
1. If you want to use a different browser driver, run  eg `./gradlew test -Ddriver.type=safaridriver -Dkarate.env=saucelabs`.

NOTE: You are able override the `SAUCE_DRIVER_CREATION_URL` value by providing the `saucelabs.driver.url` JVM option e.g.
```
./gradlew test -Dkarate.env=saucelabs -Dsaucelabs.driver.url=https://some-other-saucelabs-driver-creation-url.com
```
Author: Gek Yeo
